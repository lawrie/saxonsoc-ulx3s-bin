#include <stdio.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
  printf("Hello World!\n");
  exit(0);
  return 0;
}


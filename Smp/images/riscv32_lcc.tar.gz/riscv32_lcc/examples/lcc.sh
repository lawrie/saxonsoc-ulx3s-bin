export PATH=/riscv32_lcc/lcc/bin:/riscv32_lcc/binutils/bin:$PATH

#include <stdio.h>

main() {
  long long x;
  printf("Size of long long: %d\n", sizeof(x));
  return 0;
}



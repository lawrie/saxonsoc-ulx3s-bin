#include <unistd.h>

int main(void) {
  write(1,"Hi!\n",4);
  return 0;
}

